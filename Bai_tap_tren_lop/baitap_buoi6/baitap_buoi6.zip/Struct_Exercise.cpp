#include<bits/stdc++.h>
using namespace std ;  
typedef struct {
	  char tenVatTu[50] ;  
    char maVatTu[5] ;  
    int soLuong  ;  
    float donGia ;
}vattu; 
void nhap1VatTu(vattu &a){
	      cout<<"Nhap ma vat tu: " ; 
      fflush(stdin)  ;
      gets(a.maVatTu) ; 
      cout<<"Nhap ten vat tu: " ;
	fflush(stdin) ;   
      gets(a.tenVatTu) ;  
      cout<<"Nhap so luong vat tu: " ; 
      cin>>a.soLuong ;  
      cout<<"Nhap don gia: " ;  
      cin>>a.donGia ; 
}
void nhapVatTu(vattu a[],int &n){
    cout<<"Nhap so luong vat tu: " ;  
    cin>> n  ;  
    for(int i=0;i<n;i++)
    {	
    	cout<<"Nhap vat tu thu "<<i+1<<endl ; 
        nhap1VatTu(a[i]) ;  
    }
}
void luDanhSachVatTu(vattu a[],int n){
    FILE * p ;  
    p = fopen("data.txt","w"); 
    fprintf(p,"%-20s %-15s %-10s %-10s\n","Ten Vat tu","Ma vat tu","So luong","Don gia") ; 
    for(int i=0;i<n;i++)
    {
        fprintf(p,"%-20s %-15s %-10d %-10f\n",a[i].tenVatTu,a[i].maVatTu,a[i].soLuong,a[i].donGia) ; 
    } 
    fclose(p) ; 
}
void xuatVatTulonHon10(vattu a[],int n)
{
    FILE *p   ; 
    int flag = 0 ;    
    p =  fopen("data.dat","w"); 
    fprintf(p,"%-20s %-15s %-10s %-10s\n","Ten Vat tu","Ma vat tu","So luong","Don gia") ; 
     printf("%-20s %-15s %-10s %-10s\n","Ten Vat tu","Ma vat tu","So luong","Don gia") ; 

    for(int i=0;i<n;i++){
        if(a[i].soLuong > 10 )
        {
        fprintf(p,"%-20s %-15s %-10d %-10f\n",a[i].tenVatTu,a[i].maVatTu,a[i].soLuong,a[i].donGia) ; 
        printf("%-20s %-15s %-10d %-10f\n",a[i].tenVatTu,a[i].maVatTu,a[i].soLuong,a[i].donGia) ; 
        flag =  1;   
        }
    }
    if(!flag) cout<<"Khong co vat tu nao co so luong lon hon 10. \n" ;  
}
void cacVatTuCoDonGiaLonNhat(vattu a[],int n)
{
    float max = 0 ; 
    for(int i=0;i<n;i++)
    {
        if(max < a[i].donGia ) max = a[i].donGia  ;  
    }
    for(int i=0;i<n;i++)
    {
        if(max == a[i].donGia) cout<<a->tenVatTu<<" co don gia lon nhat! \n" ;  
    }
}
float tongTienVatTu(vattu a[],int n)
{
    float sumMoney = 0  ; 
    for(int i=0;i<n;i++)
    {
        sumMoney += float(a[i].donGia*a[i].soLuong) ; 
    }
    return sumMoney ;  
}
int main(){
        vattu a[20]  ; 
        int n   ; 
        nhapVatTu(a,n) ; 
        luDanhSachVatTu(a,n) ;  
        xuatVatTulonHon10(a,n) ;
        cacVatTuCoDonGiaLonNhat(a,n) ; 
//       cout<<"Tong tien vat tu la: "<<tongTienVatTu(a,n)<<endl ; 
	printf("Tong tien vat tu la: %f\n",tongTienVatTu(a,n)) ; 
}
